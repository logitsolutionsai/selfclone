window.YTD.tweets.part0 = [
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "1880000000001234567"
          ],
          "editableUntil": "",
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [],
        "urls": []
      },
      "display_text_range": [
        "0",
        "74"
      ],
      "favorite_count": "2",
      "id_str": "1880000000001234567",
      "truncated": false,
      "retweet_count": "0",
      "id": "1880000000001234567",
      "created_at": "Mon Apr 06 08:53:23 +0000 2026",
      "favorited": false,
      "full_text": "First sail of the year &amp; the river was glass. Best office in the world",
      "lang": "en"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "1880000000002469134"
          ],
          "editableUntil": "",
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [],
        "urls": []
      },
      "display_text_range": [
        "0",
        "70"
      ],
      "favorite_count": "2",
      "id_str": "1880000000002469134",
      "truncated": false,
      "retweet_count": "0",
      "id": "1880000000002469134",
      "created_at": "Tue Apr 07 16:42:48 +0000 2026",
      "favorited": false,
      "full_text": "Restoring a 1970s dinghy this month - the transom was basically sponge",
      "lang": "en"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "1880000000003703701"
          ],
          "editableUntil": "",
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "screen_name": "rosa_vidal"
          }
        ],
        "urls": [],
        "media": [
          {
            "url": "https://t.co/AbC123xYz9"
          }
        ]
      },
      "display_text_range": [
        "0",
        "77"
      ],
      "favorite_count": "2",
      "id_str": "1880000000003703701",
      "truncated": false,
      "retweet_count": "0",
      "id": "1880000000003703701",
      "created_at": "Wed Apr 08 20:47:02 +0000 2026",
      "favorited": false,
      "full_text": "@rosa_vidal Update: new transom is in and she floats! https://t.co/AbC123xYz9",
      "lang": "en",
      "in_reply_to_status_id_str": "1880000000002469134",
      "in_reply_to_user_id": "7770001",
      "in_reply_to_screen_name": "rosa_vidal"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "1880000000004938268"
          ],
          "editableUntil": "",
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [
          {
            "screen_name": "LisbonSailing"
          }
        ],
        "urls": [
          {
            "url": "https://t.co/Zz9Yy8Xx7W",
            "expanded_url": "https://lisbonsailing.example/regatta"
          }
        ]
      },
      "display_text_range": [
        "0",
        "86"
      ],
      "favorite_count": "2",
      "id_str": "1880000000004938268",
      "truncated": false,
      "retweet_count": "0",
      "id": "1880000000004938268",
      "created_at": "Fri Apr 10 22:26:05 +0000 2026",
      "favorited": false,
      "full_text": "RT @LisbonSailing: Entries for the spring regatta close Friday https://t.co/Zz9Yy8Xx7W",
      "lang": "en"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "1880000000006172835"
          ],
          "editableUntil": "",
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [],
        "urls": []
      },
      "display_text_range": [
        "0",
        "76"
      ],
      "favorite_count": "2",
      "id_str": "1880000000006172835",
      "truncated": false,
      "retweet_count": "0",
      "id": "1880000000006172835",
      "created_at": "Sun Apr 12 16:24:32 +0000 2026",
      "favorited": false,
      "full_text": "@joao_vela @clara_n ahah yes, the knot table was chaos but the kids loved it",
      "lang": "en",
      "in_reply_to_status_id_str": "1879999999999999999",
      "in_reply_to_screen_name": "joao_vela"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "1880000000007407402"
          ],
          "editableUntil": "",
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [],
        "urls": []
      },
      "display_text_range": [
        "0",
        "47"
      ],
      "favorite_count": "2",
      "id_str": "1880000000007407402",
      "truncated": false,
      "retweet_count": "0",
      "id": "1880000000007407402",
      "created_at": "Mon Apr 13 20:13:10 +0000 2026",
      "favorited": false,
      "full_text": "Hot take: varnish is a lifestyle, not a product",
      "lang": "en"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "1880000000008641969"
          ],
          "editableUntil": "",
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [],
        "urls": [
          {
            "url": "https://t.co/Qq1Ww2Ee3R",
            "expanded_url": "https://example.org/wooden-boats"
          }
        ]
      },
      "display_text_range": [
        "0",
        "70"
      ],
      "favorite_count": "2",
      "id_str": "1880000000008641969",
      "truncated": false,
      "retweet_count": "0",
      "id": "1880000000008641969",
      "created_at": "Wed Apr 15 08:28:43 +0000 2026",
      "favorited": false,
      "full_text": "Epoxy is not magic. Good wood and patience are https://t.co/Qq1Ww2Ee3R",
      "lang": "en"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "1880000000009876536"
          ],
          "editableUntil": "",
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [],
        "urls": []
      },
      "display_text_range": [
        "0",
        "107"
      ],
      "favorite_count": "2",
      "id_str": "1880000000009876536",
      "truncated": false,
      "retweet_count": "0",
      "id": "1880000000009876536",
      "created_at": "Thu Apr 16 13:24:28 +0000 2026",
      "favorited": false,
      "full_text": "Teaching kids to sail is the best part of my week. Nobody complains about the cold like a 9 year old though",
      "lang": "en"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "1880000000011111103"
          ],
          "editableUntil": "",
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [],
        "urls": []
      },
      "display_text_range": [
        "0",
        "52"
      ],
      "favorite_count": "2",
      "id_str": "1880000000011111103",
      "truncated": false,
      "retweet_count": "0",
      "id": "1880000000011111103",
      "created_at": "Fri Apr 17 22:09:50 +0000 2026",
      "favorited": false,
      "full_text": "RT @WoodenBoatMag: Ten classic dinghies worth saving",
      "lang": "en"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "1880000000012345670"
          ],
          "editableUntil": "",
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [],
        "urls": []
      },
      "display_text_range": [
        "0",
        "73"
      ],
      "favorite_count": "2",
      "id_str": "1880000000012345670",
      "truncated": false,
      "retweet_count": "0",
      "id": "1880000000012345670",
      "created_at": "Sun Apr 19 19:44:45 +0000 2026",
      "favorited": false,
      "full_text": "Three coats of varnish down, two to go. My hands smell like a pine forest",
      "lang": "en"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "1880000000013580237"
          ],
          "editableUntil": "",
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [],
        "urls": []
      },
      "display_text_range": [
        "0",
        "45"
      ],
      "favorite_count": "2",
      "id_str": "1880000000013580237",
      "truncated": false,
      "retweet_count": "0",
      "id": "1880000000013580237",
      "created_at": "Mon Apr 20 18:43:06 +0000 2026",
      "favorited": false,
      "full_text": "@marta_s it was so good!! same time next year",
      "lang": "en",
      "in_reply_to_status_id_str": "1879999999999999000",
      "in_reply_to_screen_name": "marta_s"
    }
  },
  {
    "tweet": {
      "edit_info": {
        "initial": {
          "editTweetIds": [
            "1880000000014814804"
          ],
          "editableUntil": "",
          "editsRemaining": "5",
          "isEditEligible": true
        }
      },
      "retweeted": false,
      "source": "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities": {
        "hashtags": [],
        "symbols": [],
        "user_mentions": [],
        "urls": []
      },
      "display_text_range": [
        "0",
        "64"
      ],
      "favorite_count": "2",
      "id_str": "1880000000014814804",
      "truncated": false,
      "retweet_count": "0",
      "id": "1880000000014814804",
      "created_at": "Tue Apr 21 14:56:20 +0000 2026",
      "favorited": false,
      "full_text": "PSA: check your bilge pumps before the spring storms, not during",
      "lang": "en"
    }
  }
]